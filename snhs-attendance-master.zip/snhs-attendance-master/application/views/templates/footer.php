<script>
    var SITE_URL = "<?= site_url() ?>";
</script>
<script src="<?= site_url() ?>/assets/js/core/jquery.3.2.1.min.js"></script>
<script src="<?= site_url() ?>/assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="<?= site_url() ?>/assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
<script src="<?= site_url() ?>/assets/js/core/popper.min.js"></script>
<script src="<?= site_url() ?>/assets/js/core/bootstrap.min.js"></script>
<script src="<?= site_url() ?>/assets/js/atlantis.js"></script>

<!-- jQuery Scrollbar -->
<script src="<?= site_url() ?>/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

<!-- Moment JS -->
<script src="<?= site_url() ?>/assets/js/plugin/moment/moment.min.js"></script>

<!-- Datatables -->
<script src="<?= site_url() ?>/assets/js/plugin/datatables/datatables.min.js"></script>

<!-- Bootstrap Notify -->
<script src="<?= site_url() ?>/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>

<!-- Bootstrap Toggle -->
<script src="<?= site_url() ?>/assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>

<!-- DateTimePicker -->
<script src="<?= site_url() ?>/assets/js/plugin/datepicker/bootstrap-datetimepicker.min.js"></script>

<!-- Bootstrap Tagsinput -->
<script src="<?= site_url() ?>/assets/js/plugin/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>

<!-- jQuery Validation -->
<script src="<?= site_url() ?>/assets/js/plugin/jquery.validate/jquery.validate.min.js"></script>

<!-- Select2 -->
<script src="<?= site_url() ?>/assets/js/plugin/select2/select2.full.min.js"></script>

<!-- Magnific Popup -->
<script src="<?= site_url() ?>/assets/js/plugin/jquery.magnific-popup/jquery.magnific-popup.min.js"></script>

<script src="<?= site_url() ?>assets/js/plugin/dataTables.dateTime.min.js"></script>
<script src="<?= site_url() ?>assets/js/plugin/datatables/Buttons-1.6.1/js/dataTables.buttons.min.js"></script>
<script src="<?= site_url() ?>assets/js/plugin/datatables/pdfmake-0.1.36/pdfmake.min.js"></script>
<script src="<?= site_url() ?>assets/js/plugin/datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
<script src="<?= site_url() ?>assets/js/plugin/datatables/Buttons-1.6.1/js/buttons.html5.min.js"></script>
<script src="<?= site_url() ?>assets/js/plugin/datatables/Buttons-1.6.1/js/buttons.print.min.js"></script>

<script src="<?= site_url() ?>/assets/js/customScript.js"></script>
<script src="<?= site_url() ?>/assets/js/ajaxForms.js"></script>