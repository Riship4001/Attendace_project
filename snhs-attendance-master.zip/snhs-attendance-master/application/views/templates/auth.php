
<!DOCTYPE html>
<html lang="en">
<head>
	<?php $this->load->view('templates/header.php') ?>
</head>
<body class="login">
	<div class="wrapper wrapper-login">
        <?= $content ?> 
	</div>
	<?php $this->load->view('templates/footer.php') ?>
</body>
</html>